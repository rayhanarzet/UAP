package uap.interfaces;

public interface Kalkulasi {
double getVolume();
double getSurfaceArea();
double getMass();
void printInfo();
}
